from .func_inject import *
from .method_inject import *
