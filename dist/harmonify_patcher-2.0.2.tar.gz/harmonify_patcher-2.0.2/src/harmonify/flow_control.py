# Continue executing original & postfix
CONTINUE_EXEC = "continue"
# Continue executing original, but not postfix
CONTINUE_WITHOUT_POSTFIX = "continue_npf"
# Don't execute anything else
STOP_EXEC = "stop"